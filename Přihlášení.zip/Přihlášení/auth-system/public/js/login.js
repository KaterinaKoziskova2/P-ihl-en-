const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { check, validationResult } = require('express-validator');
const pool = require('../db/database');

const isNotAuthenticated = (req, res, next) => {
  if (!req.session.user) {
    return next();
  }
  return res.redirect('/profile');
};

router.get('/', isNotAuthenticated, (req, res) => {
  res.render('login', { 
    title: 'Přihlášení',
    errors: [],
    username: ''
  });
});

router.post('/', [
  check('username')
    .trim()
    .notEmpty().withMessage('Uživatelské jméno je povinné'),
  check('password')
    .notEmpty().withMessage('Heslo je povinné')
], async (req, res) => {
  const errors = validationResult(req);
  const { username, password } = req.body;

  if (!errors.isEmpty()) {
    return res.render('login', {
      title: 'Přihlášení',
      errors: errors.array(),
      username
    });
  }

  try {
    const [users] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);

    if (users.length === 0) {
      return res.render('login', {
        title: 'Přihlášení',
        errors: [{ msg: 'Neplatné přihlašovací údaje' }],
        username
      });
    }

    const user = users[0];

    const match = await bcrypt.compare(password, user.password);
    
    if (!match) {
      return res.render('login', {
        title: 'Přihlášení',
        errors: [{ msg: 'Neplatné přihlašovací údaje' }],
        username
      });
    }

    req.session.user = {
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email
    };

    res.redirect('/profile');

  } catch (error) {
    console.error('Chyba při přihlašování:', error);
    res.status(500).render('login', {
      title: 'Přihlášení',
      errors: [{ msg: 'Nastala chyba při přihlašování. Zkuste to prosím znovu.' }],
      username
    });
  }
});

module.exports = router;