document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    const formMessage = document.getElementById('form-message');

    function validateUsername(username) {
      if (!username) return 'Uživatelské jméno je povinné';
      if (username.length < 3) return 'Uživatelské jméno musí mít alespoň 3 znaky';
      return '';
    }
    
    function validateName(name) {
      if (!name) return 'Jméno je povinné';
      return '';
    }
    
    function validateEmail(email) {
      if (!email) return 'Email je povinný';
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) return 'Zadejte platný email';
      return '';
    }
    
    function validatePassword(password) {
      if (!password) return 'Heslo je povinné';
      if (password.length < 6) return 'Heslo musí mít alespoň 6 znaků';
      return '';
    }
    
    function validatePasswordConfirm(password, passwordConfirm) {
      if (!passwordConfirm) return 'Potvrzení hesla je povinné';
      if (password !== passwordConfirm) return 'Hesla se neshodují';
      return '';
    }

    registerForm.addEventListener('submit', async function(e) {
      e.preventDefault();

      const username = document.getElementById('username').value.trim();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const passwordConfirm = document.getElementById('password-confirm').value;
ta
      const usernameError = validateUsername(username);
      const nameError = validateName(name);
      const emailError = validateEmail(email);
      const passwordError = validatePassword(password);
      const passwordConfirmError = validatePasswordConfirm(password, passwordConfirm);

      document.getElementById('username-error').textContent = usernameError;
      document.getElementById('name-error').textContent = nameError;
      document.getElementById('email-error').textContent = emailError;
      document.getElementById('password-error').textContent = passwordError;
      document.getElementById('password-confirm-error').textContent = passwordConfirmError;

      if (!usernameError && !nameError && !emailError && !passwordError && !passwordConfirmError) {
        try {
          const response = await fetch('/api/users/register', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              username,
              name,
              email,
              password
            })
          });
          
          const data = await response.json();
          
          if (response.ok) {
            formMessage.textContent = 'Registrace úspěšná! Přesměrování...';
            formMessage.className = 'message success';

            setTimeout(() => {
              window.location.href = '/profile';
            }, 2000);
          } else {
            formMessage.textContent = data.msg || 'Registrace selhala.';
            formMessage.className = 'message error';
          }
        } catch (error) {
          formMessage.textContent = 'Chyba připojení k serveru.';
          formMessage.className = 'message error';
          console.error('Chyba:', error);
        }
      }
    });
  });