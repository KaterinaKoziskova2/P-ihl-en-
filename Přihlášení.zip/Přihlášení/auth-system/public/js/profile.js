const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { check, validationResult } = require('express-validator');
const pool = require('../db/database');

const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  req.flash('error', 'Pro přístup k profilu se musíte přihlásit');
  return res.redirect('/login');
};

router.get('/', isAuthenticated, (req, res) => {
  res.render('profile', {
    title: 'Uživatelský profil',
    user: req.session.user,
    errors: [],
    success: req.flash('success')
  });
});

router.get('/edit', isAuthenticated, (req, res) => {
  res.render('profile-edit', {
    title: 'Upravit profil',
    user: req.session.user,
    errors: []
  });
});

router.post('/edit', isAuthenticated, [
  check('name')
    .trim()
    .notEmpty().withMessage('Jméno je povinné')
    .isLength({ max: 100 }).withMessage('Jméno může mít maximálně 100 znaků'),
  check('email')
    .trim()
    .notEmpty().withMessage('Email je povinný')
    .isEmail().withMessage('Zadejte platný email')
    .isLength({ max: 100 }).withMessage('Email může mít maximálně 100 znaků')
    .normalizeEmail(),
  check('current_password')
    .optional({ checkFalsy: true }),
  check('new_password')
    .optional({ checkFalsy: true })
    .isLength({ min: 8 }).withMessage('Heslo musí mít minimálně 8 znaků')
    .matches(/\d/).withMessage('Heslo musí obsahovat alespoň jedno číslo')
    .matches(/[A-Z]/).withMessage('Heslo musí obsahovat alespoň jedno velké písmeno'),
  check('confirm_password')
    .optional({ checkFalsy: true })
    .custom((value, { req }) => {
      if (value && value !== req.body.new_password) {
        throw new Error('Hesla se neshodují');
      }
      return true;
    })
], async (req, res) => {
  const errors = validationResult(req);
  const { name, email, current_password, new_password } = req.body;
  const userId = req.session.user.id;

  if (!errors.isEmpty()) {
    return res.render('profile-edit', {
      title: 'Upravit profil',
      user: { ...req.session.user, name, email },
      errors: errors.array()
    });
  }

  try {
    const [users] = await pool.query('SELECT * FROM users WHERE id = ?', [userId]);
    
    if (users.length === 0) {
      req.flash('error', 'Uživatel nebyl nalezen');
      return res.redirect('/login');
    }

    const user = users[0];
    let updateParams = [name, email];
    let updateQuery = 'UPDATE users SET name = ?, email = ?';

    if (new_password) {
      if (!current_password) {
        return res.render('profile-edit', {
          title: 'Upravit profil',
          user: { ...req.session.user, name, email },
          errors: [{ msg: 'Pro změnu hesla musíte zadat současné heslo' }]
        });
      }

      const match = await bcrypt.compare(current_password, user.password);
      
      if (!match) {
        return res.render('profile-edit', {
          title: 'Upravit profil',
          user: { ...req.session.user, name, email },
          errors: [{ msg: 'Současné heslo není správné' }]
        });
      }

      const hashedPassword = await bcrypt.hash(new_password, 10);
      updateQuery += ', password = ?';
      updateParams.push(hashedPassword);
    }

    updateQuery += ' WHERE id = ?';
    updateParams.push(userId);
ů
    await pool.query(updateQuery, updateParams);

    req.session.user = {
      ...req.session.user,
      name,
      email
    };

    req.flash('success', 'Profil byl úspěšně aktualizován');
    res.redirect('/profile');

  } catch (error) {
    console.error('Chyba při aktualizaci profilu:', error);

    if (error.code === 'ER_DUP_ENTRY' && error.sqlMessage.includes('email')) {
      return res.render('profile-edit', {
        title: 'Upravit profil',
        user: { ...req.session.user, name, email },
        errors: [{ msg: 'Tento email je již používán' }]
      });
    }

    res.status(500).render('profile-edit', {
      title: 'Upravit profil',
      user: { ...req.session.user, name, email },
      errors: [{ msg: 'Nastala chyba při aktualizaci profilu. Zkuste to prosím znovu.' }]
    });
  }
});

router.post('/logout', isAuthenticated, (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Chyba při odhlašování:', err);
    }
    res.redirect('/login');
  });
});

module.exports = router;