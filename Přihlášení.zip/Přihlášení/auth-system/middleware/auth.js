const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    
    if (!token) {
      return res.status(401).json({ msg: 'Není autorizační token, přístup odepřen' });
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'tajnyklic');

      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ msg: 'Token není platný' });
    }
  } catch (err) {
    console.error('Chyba v auth middleware:', err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};

module.exports = auth;