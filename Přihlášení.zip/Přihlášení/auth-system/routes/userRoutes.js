const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const userController = require('../controllers/userController');
const auth = require('../middleware/auth');

// @route   POST /api/users/register
// @desc    Registrace uživatele
// @access  Public
router.post(
  '/register',
  [
    check('username', 'Prosím zadejte uživatelské jméno').notEmpty(),
    check('username', 'Uživatelské jméno musí mít alespoň 3 znaky').isLength({ min: 3 }),
    check('name', 'Prosím zadejte jméno').notEmpty(),
    check('email', 'Prosím zadejte platný email').isEmail(),
    check('password', 'Heslo musí mít alespoň 6 znaků').isLength({ min: 6 })
  ],
  userController.register
);

// @route   POST /api/users/login
// @desc    Přihlášení uživatele
// @access  Public
router.post(
  '/login',
  [
    check('username', 'Prosím zadejte uživatelské jméno').notEmpty(),
    check('password', 'Prosím zadejte heslo').notEmpty()
  ],
  userController.login
);

// @route   POST /api/users/logout
// @desc    Odhlášení uživatele
// @access  Private
router.post('/logout', auth, userController.logout);

// @route   GET /api/users/me
// @desc    Získání přihlášeného uživatele
// @access  Private
router.get('/me', auth, userController.getUser);

// @route   PUT /api/users/update
// @desc    Aktualizace uživatele
// @access  Private
router.put(
  '/update',
  [
    auth,
    check('name', 'Prosím zadejte jméno').notEmpty(),
    check('email', 'Prosím zadejte platný email').isEmail()
  ],
  userController.updateUser
);

// @route   PUT /api/users/change-password
// @desc    Změna hesla
// @access  Private
router.put(
  '/change-password',
  [
    auth,
    check('currentPassword', 'Prosím zadejte aktuální heslo').notEmpty(),
    check('newPassword', 'Nové heslo musí mít alespoň 6 znaků').isLength({ min: 6 })
  ],
  userController.changePassword
);

module.exports = router;