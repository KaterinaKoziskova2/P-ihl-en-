const { pool } = require('../config/db');
const bcrypt = require('bcryptjs');

class User {
  static async findByUsername(username) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE username = ?',
        [username]
      );
      return rows[0];
    } catch (error) {
      console.error('Chyba při hledání uživatele podle username:', error);
      throw error;
    }
  }

  static async findByEmail(email) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE email = ?',
        [email]
      );
      return rows[0];
    } catch (error) {
      console.error('Chyba při hledání uživatele podle email:', error);
      throw error;
    }
  }

  static async findById(id) {
    try {
      const [rows] = await pool.execute(
        'SELECT id, username, name, email FROM users WHERE id = ?',
        [id]
      );
      return rows[0];
    } catch (error) {
      console.error('Chyba při hledání uživatele podle ID:', error);
      throw error;
    }
  }

  static async create(userData) {
    const { username, name, email, password } = userData;

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    try {
      const [result] = await pool.execute(
        'INSERT INTO users (username, name, email, password) VALUES (?, ?, ?, ?)',
        [username, name, email, hashedPassword]
      );
      
      return result.insertId;
    } catch (error) {
      console.error('Chyba při vytváření uživatele:', error);
      throw error;
    }
  }

  static async update(id, userData) {
    const { name, email } = userData;
    
    try {
      const [result] = await pool.execute(
        'UPDATE users SET name = ?, email = ? WHERE id = ?',
        [name, email, id]
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Chyba při aktualizaci uživatele:', error);
      throw error;
    }
  }

  static async updatePassword(id, password) {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    try {
      const [result] = await pool.execute(
        'UPDATE users SET password = ? WHERE id = ?',
        [hashedPassword, id]
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Chyba při aktualizaci hesla:', error);
      throw error;
    }
  }

  static async comparePassword(password, hashedPassword) {
    return await bcrypt.compare(password, hashedPassword);
  }
}

module.exports = User;