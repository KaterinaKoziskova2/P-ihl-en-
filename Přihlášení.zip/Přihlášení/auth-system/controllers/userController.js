const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');

exports.register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, name, email, password } = req.body;

  try {
    let user = await User.findByUsername(username);
    if (user) {
      return res.status(400).json({ msg: 'Uživatel s tímto uživatelským jménem již existuje' });
    }

    user = await User.findByEmail(email);
    if (user) {
      return res.status(400).json({ msg: 'Uživatel s tímto emailem již existuje' });
    }

    const userId = await User.create({
      username,
      name,
      email,
      password
    });

    const payload = {
      user: {
        id: userId
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET || 'tajnyklic',
      { expiresIn: '1h' },
      (err, token) => {
        if (err) throw err;
        res.cookie('token', token, { 
          httpOnly: true,
          maxAge: 3600000 
        });
        res.status(201).json({ msg: 'Uživatel vytvořen', userId });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};

exports.login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, password } = req.body;

  try {
    const user = await User.findByUsername(username);
    if (!user) {
      return res.status(400).json({ msg: 'Neplatné přihlašovací údaje' });
    }

    const isMatch = await User.comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Neplatné přihlašovací údaje' });
    }

    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET || 'tajnyklic',
      { expiresIn: '1h' },
      (err, token) => {
        if (err) throw err;
        res.cookie('token', token, { 
          httpOnly: true,
          maxAge: 3600000 
        });
        res.json({ msg: 'Přihlášení úspěšné' });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};

exports.logout = (req, res) => {
  res.clearCookie('token');
  res.json({ msg: 'Odhlášení úspěšné' });
};

exports.getUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'Uživatel nenalezen' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};

exports.updateUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email } = req.body;

  try {
    const existingUser = await User.findByEmail(email);
    if (existingUser && existingUser.id !== req.user.user.id) {
      return res.status(400).json({ msg: 'Email je již používán' });
    }

    const updated = await User.update(req.user.user.id, { name, email });
    if (!updated) {
      return res.status(404).json({ msg: 'Uživatel nenalezen' });
    }

    res.json({ msg: 'Uživatel aktualizován' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};

exports.changePassword = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { currentPassword, newPassword } = req.body;

  try {
    const user = await User.findByUsername((await User.findById(req.user.user.id)).username);
    if (!user) {
      return res.status(404).json({ msg: 'Uživatel nenalezen' });
    }

    const isMatch = await User.comparePassword(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Nesprávné aktuální heslo' });
    }

    await User.updatePassword(req.user.user.id, newPassword);

    res.json({ msg: 'Heslo změněno' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Chyba serveru' });
  }
};